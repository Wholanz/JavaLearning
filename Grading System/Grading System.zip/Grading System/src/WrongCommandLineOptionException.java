
public class WrongCommandLineOptionException extends Exception{
	public WrongCommandLineOptionException(String message){
		super(message); 
	}
}
